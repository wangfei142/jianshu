const express = require('express');
const app = express();

// 引入路由中间件
const userRouter = require('./routes/user');
const articleRouter = require('./routes/article');

// 设置 req.body
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// 设置允许跨域 cors
app.use((req, res, next) => {
  res.set('Access-Control-Allow-Origin', '*');
  res.set('Access-Control-Allow-Methods', 'GET, POST, DELETE, UPDATE, PUT');
  next();
})

app.use('/api/user', userRouter);
app.use('/api', articleRouter);

app.listen(8080);
