const db = require('../config/db');
const schema = db.Schema({
  username: { //用户名
    type: String,
    required: true
  },
  nickname: { //昵称
    type: String,
    required: true
  },
  password: { //密码
    type: String,
    required: true
  },
  isvip: { //会员
    type: Number,
    default: 4
  },
  avatar: {  //用户头像
    type: String,
    default: 'http://img3.imgtn.bdimg.com/it/u=1820523987,3798556096&fm=26&gp=0.jpg'
  },
});
module.exports = db.model('user', schema);
