const db = require('../config/db');
const schema = db.Schema({
  title: {   // 评论文章
    type: String,
    required: true
  },
  nickname: {   // 评论人
    type: String,
    required: true
  },
  retime: {    //评论时间
    type: String,
    required: true
  },
  content: {   //评论内容
    type: String,
    required: true
  },
  avatar: {  //评论人头像
    type: String,
    default: 'http://img3.imgtn.bdimg.com/it/u=1820523987,3798556096&fm=26&gp=0.jpg'
  },
})
module.exports = db.model('comment', schema);
