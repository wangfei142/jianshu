const db = require('../config/db');
const schema = db.Schema({
  nickname: {  //作者
    type: String,
    required: true
  },
  posted_time: {  // 发表时间
    type: String,
    required: true
  },
  title: {  // 文章标题
    type: String,
    required: true
  },
  hot: {  // 热度
    type: String,
    default: 3
  },
  discuss: {  //  评论次数
    type: String,
    default: 5
  },
  like: {  // 喜欢
    type: String,
    default: 8
  },
  avatar: {  //作者头像
    type: String,
    default: 'http://img3.imgtn.bdimg.com/it/u=1820523987,3798556096&fm=26&gp=0.jpg'
  },
  data: { // 文章
    type: String,
    required: true
  }
})
module.exports = db.model('article', schema);
