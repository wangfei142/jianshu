const express = require('express');
const router = express.Router();
const ArticleModel = require('../model/article');
const CommentModel = require('../model/comment');
// 添加文章 /api/article
router.post('/article', (req, res) => {

  let article = new ArticleModel({
    nickname: req.body.nickname,
    title: req.body.title,
    data: req.body.data,
    posted_time: req.body.posted_time
  });
  article.save()
    .then(data => {
      res.send({
        code: 0,
        msg: 'ok'
      })
    })
})





// 查询 /api/student
router.get('/article', (req, res) => {
  let author = req.query.author;
  author = new RegExp(author);
  ArticleModel.find({ author }).count().then(nums => {
    ArticleModel.find({ author })
      .then(data => {
        console.log(data);
        res.send({
          code: 0,
          msg: 'ok',
          data: {
            list: data,
          }
        })
      })
  })
})

// 删除文章
router.delete('/article/:id', (req, res) => {
  // 1. 得到url地址上的 id 的值
  let id = req.params.id;
  // 2. 删除操作
  ArticleModel.deleteOne({
    _id: id
  }).then(data => {
    // 需要判断data中是否真的删除成功
    console.log(data);
    if (data.deletedCount > 0) {
      res.send({
        code: 0,
        msg: '删除成功'
      })
    } else {
      res.send({
        code: -1,
        msg: '删除失败，没有此文章'
      })
    }
  })
})
// 添加评论 /api/comment

router.post('/comment', (req, res) => {

  let article = new CommentModel({
    title: req.body.title,   // 评论文章
    nickname: req.body.nickname,   // 评论人
    retime: req.body.retime,   // 评论时间
    content: req.body.content   // 评论内容
  });
  article.save()
    .then(data => {
      res.send({
        code: 0,
        msg: 'ok'
      })
    })
})

// 查询 /api/comment
router.get('/comment', (req, res) => {
  let nickname = req.query.autnicknamehor;
  nickname = new RegExp(nickname);
  CommentModel.find({ nickname }).count().then(nums => {
    CommentModel.find({ nickname })
      .then(data => {
        console.log(data);
        res.send({
          code: 0,
          msg: 'ok',
          data: {
            list: data,
          }
        })
      })
  })
})

// 删除评论
router.delete('/comment/:id', (req, res) => {
  // 1. 得到url地址上的 id 的值
  let id = req.params.id;
  // 2. 删除操作
  CommentModel.deleteOne({
    _id: id
  }).then(data => {
    // 需要判断data中是否真的删除成功
    console.log(data);
    if (data.deletedCount > 0) {
      res.send({
        code: 0,
        msg: '删除成功'
      })
    } else {
      res.send({
        code: -1,
        msg: '删除失败，没有此评论'
      })
    }
  })
})



module.exports = router;
